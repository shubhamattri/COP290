var searchData=
[
  ['calculate_5fdistance_5f2d',['calculate_distance_2D',['../functions_8h.html#a95d9918ecf65d9150a4b65b19f26918b',1,'functions.h']]],
  ['calculate_5fdistance_5f3d',['calculate_distance_3D',['../functions_8h.html#aa1c6b5780f30e4a1ce84762e5f5c671d',1,'functions.h']]]
];
